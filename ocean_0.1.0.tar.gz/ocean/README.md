# ocean
R package for metabolic enzyme enrichment anaylsis

![alt text](https://github.com/saezlab/ocean/blob/master/ocean_logo.pdf?raw=true)
